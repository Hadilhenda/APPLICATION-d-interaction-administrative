
from flask import request, Blueprint,jsonify
from frame import db
from ..models.hopitals import hopitaux

api_hopitals = Blueprint('api_hopitals', __name__)


@api_hopitals.route('/api/hopitals')
def get_hopitals():
	return jsonify([
		{
			'id': hopitaux.id, 'nom': hopitaux.nom, 'email': hopitaux.email,
			'cin': hopitaux.cin,'tel': hopitaux.tel,'date_ins': hopitaux.date_ins
			} for hopital in hopitaux.query.all()
	])
		
@api_hopitals.route('/api/hopital/<id>/')
def get_hopital(id):
	print(id)
	hopital = hopitaux.query.filter_by(id=id).first_or_404()
	return {
		'id': hopitaux.id, 'nom': hopitaux.nom, 'email': hopitaux.email,
			'cin': hopitaux.cin,'tel': hopitaux.tel,'date_ins': hopitaux.date_ins
		}

@api_hopitals.route('/api/hopital/add', methods=['POST'])
def create_hopital():
	data = request.get_json()
	if not 'nom' in data or not 'email' in data:
		return jsonify({
			'error': 'Bad Request',
			'message': 'nom or email not given'
		}), 400
	if len(data['nom']) < 4 or len(data['email']) < 4:
		return jsonify({
			'error': 'Bad Request',
			'message': 'nom and email must be contain minimum of 4 letters'
		}), 400
	entry = hopitals(
	
			email=data['email'],
	
			tel=data['tel']
			
		)
	db.session.add(entry)
	db.session.commit()
	return {
		'id': entry.id, 'nom': entry.nom, 'email': entry.email,
			'cin': entry.cin,'tel': entry.tel,'date_ins': entry.date_ins 
	}, 201

@api_hopitals.route('/api/hopital/update/<id>', methods=['PUT'])
def uptel(id):
	data = request.get_json()
	if 'nom' not in data:
		return {
			'error': 'Bad Request',
			'message': 'nom field needs to be present'
		}, 400
	hopital = hopitaux.query.filter_by(id=id).first_or_404()
	
	hopitaux.email=data['email']

	hopitaux.tel=data['tel']
	
	
	db.session.commit()
	return jsonify({
		'id': hopitaux.id, 'nom': hopitaux.nom, 'email': hopitaux.email,
			'cin': hopitaux.cin,'tel': hopitaux.tel,'date_ins': hopitaux.date_ins
		})

@api_hopitals.route('/api/hopital/delete/<id>', methods=['DELETE'] )
def delete_hopital(id):
	hopital = hopitaux.query.filter_by(id=id).first_or_404()
	db.session.delete(hopital)
	db.session.commit()
	return {
		'success': 'Data deleted successfully'
	}

    

  

    
    